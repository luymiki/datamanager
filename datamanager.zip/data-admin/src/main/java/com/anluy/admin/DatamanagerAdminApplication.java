package com.anluy.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatamanagerAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatamanagerAdminApplication.class, args);
	}
}
