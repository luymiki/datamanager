package com.anluy.admin.mapper;

import com.anluy.admin.entity.Suspicious;
import com.anluy.commons.dao.BaseDAO;
import org.springframework.stereotype.Component;

/**
 * 功能说明：
 * <p>
 * Created by hc.zeng on 2018/3/22.
 */
@Component
public interface SuspiciousMapper extends BaseDAO<String,Suspicious>{

}
