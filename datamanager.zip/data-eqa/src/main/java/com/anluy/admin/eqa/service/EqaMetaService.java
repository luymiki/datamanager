package com.anluy.admin.eqa.service;

import com.anluy.admin.eqa.entity.EqaMeta;

import java.util.List;

/**
 * 功能说明：
 * <p>
 * Created by hc.zeng on 2018/3/26.
 */
public interface EqaMetaService {
    List<EqaMeta> getAll();
}
