jQuery(function() {
    'use strict';

    var webuloader = (function($){
        var $wrap = $('#uploader'),

            // 图片容器
            $queue = $('<ul class="filelist"></ul>')
                .appendTo( $wrap.find('.queueList') ),

            // 状态栏，包括进度和控制按钮
            $statusBar = $wrap.find('.statusBar'),

            // 文件总体选择信息。
            $info = $statusBar.find('.info'),

            // 上传按钮
            $upload = $wrap.find('#uploadBtn'),

            // 没选择文件之前的内容。
            $placeHolder = $wrap.find('.placeholder'),

            // 总体进度条
            $progress = $statusBar.find('.progress').hide(),

            // 添加的文件数量
            fileCount = 0,

            // 添加的文件总大小
            fileSize = 0,

            // 优化retina, 在retina下这个值是2
            ratio = window.devicePixelRatio || 1,

            // 缩略图大小
            thumbnailWidth = 110 * ratio,
            thumbnailHeight = 110 * ratio,

            // 可能有pedding, ready, uploading, confirm, done.
            state = 'pedding',

            // 所有文件的进度信息，key为file id
            percentages = {},

            supportTransition = (function(){
                var s = document.createElement('p').style,
                    r = 'transition' in s ||
                        'WebkitTransition' in s ||
                        'MozTransition' in s ||
                        'msTransition' in s ||
                        'OTransition' in s;
                s = null;
                return r;
            })(),

            // WebUploader实例
            uploader,
            text;

        if ( !WebUploader.Uploader.support() ) {
            alert( 'Web Uploader 不支持您的浏览器！如果你使用的是IE浏览器，请尝试升级 flash 播放器');
            throw new Error( 'WebUploader does not support the browser you are using.' );
        }

        // 实例化
        uploader = WebUploader.create({
            pick: {
                id: '#filePicker',
                label: '点击选择文件'
            },
            dnd: '#uploader .queueList',
            paste: document.body,

            // accept: {
            //     title: 'Images',
            //     extensions: 'gif,jpg,jpeg,bmp,png',
            //     mimeTypes: 'image/*'
            // },

            // swf文件路径
            swf: '/js/plugins/webuploader/Uploader.swf',

            disableGlobalDnd: true,
            accept: window.accept||null,
            chunked: false,//禁止分片上传
            server: '/api/admin/file/upload',
            fileNumLimit: window.fileNumLimit || 10,//添加文件的总个数
            fileSizeLimit: 2048 * 1024 * 1024,    // 2G
            fileSingleSizeLimit: 2048 * 1024 * 1024    // 2G
        });

        // 添加“添加文件”的按钮，
        uploader.addButton({
            id: '#filePicker2',
            label: '继续添加'
        });

        var _showError = function( code ) {
            switch( code.toLocaleLowerCase()) {
                case 'exceed_size':
                case 'f_exceed_size':
                    return '文件大小超出';
                case 'interrupt':
                case 'f_interrupt':
                    return '上传暂停';
                case 'f_duplicate':
                    return '文件重复';
                case 'q_type_denied':
                    return '不支持的文件格式，请重新选择';
                case 'q_exceed_num_limit':
                    return '超过最大支持文件数';
                default:
                    return '上传失败，请重试';
            }
        };

        // 当有文件添加进来时执行，负责view的创建
        function addFile( file ) {
            var $li = $( '<li id="' + file.id + '">' +
                    '<p class="title">' + file.name + '</p>' +
                    '<p class="imgWrap"></p>'+
                    '<p class="progress"><span></span></p>' +
                    '</li>' );

            var $btns = $('<div class="file-panel">' +
                '<span class="cancel">删除</span>' +
                '<span class="rotateRight">向右旋转</span>' +
                '<span class="rotateLeft">向左旋转</span></div>').appendTo( $li );


            var $prgress = $li.find('p.progress span'),
                $wrap = $li.find( 'p.imgWrap' ),
                $info = $('<p class="error"></p>');

            var showError = function( code ) {
                text = _showError(code);
                $info.text( text ).appendTo( $li );
            };

            if ( file.getStatus() === 'invalid' ) {
                showError( file.statusText );
            } else {
                // @todo lazyload
                $wrap.text( '预览中' );
                uploader.makeThumb( file, function( error, src ) {
                    var img;
                    if ( error ) {
                        $($btns.find(".rotateRight,.rotateLeft")).hide();
                        img = $('<i class="fa fa-file thumb-file"></i>');
                    }else {
                        img = $('<img src="'+src+'">');
                    }
                    $wrap.empty().append( img );
                }, thumbnailWidth, thumbnailHeight );

                percentages[ file.id ] = [ file.size, 0 ];
                file.rotation = 0;
            }

            file.on('statuschange', function( cur, prev ) {
                if ( prev === 'progress' ) {
                    $prgress.hide().width(0);
                } else if ( prev === 'queued' ) {
                    $li.off( 'mouseenter mouseleave' );
                    $btns.remove();
                }

                // 成功
                if ( cur === 'error' || cur === 'invalid' ) {
                    console.log( file.statusText );
                    showError( file.statusText );
                    percentages[ file.id ][ 1 ] = 1;
                } else if ( cur === 'interrupt' ) {
                    showError( 'interrupt' );
                } else if ( cur === 'queued' ) {
                    percentages[ file.id ][ 1 ] = 0;
                } else if ( cur === 'progress' ) {
                    $info.remove();
                    $prgress.css('display', 'block');
                } else if ( cur === 'complete' ) {
                    $li.append( '<span class="success"></span>' );
                }

                $li.removeClass( 'state-' + prev ).addClass( 'state-' + cur );
            });

            $li.on( 'mouseenter', function() {
                $btns.stop().animate({height: 30});
            });

            $li.on( 'mouseleave', function() {
                $btns.stop().animate({height: 0});
            });

            $btns.on( 'click', 'span', function() {
                var index = $(this).index(),
                    deg;

                switch ( index ) {
                    case 0:
                        uploader.removeFile( file );
                        return;

                    case 1:
                        file.rotation += 90;
                        break;

                    case 2:
                        file.rotation -= 90;
                        break;
                }

                if ( supportTransition ) {
                    deg = 'rotate(' + file.rotation + 'deg)';
                    $wrap.css({
                        '-webkit-transform': deg,
                        '-mos-transform': deg,
                        '-o-transform': deg,
                        'transform': deg
                    });
                } else {
                    $wrap.css( 'filter', 'progid:DXImageTransform.Microsoft.BasicImage(rotation='+ (~~((file.rotation/90)%4 + 4)%4) +')');
                }


            });

            $li.appendTo( $queue );
        }

        // 负责view的销毁
        function removeFile( file ) {
            var $li = $('#'+file.id);

            delete percentages[ file.id ];
            updateTotalProgress();
            $li.off().find('.file-panel').off().end().remove();
        }

        function updateTotalProgress() {
            var loaded = 0,
                total = 0,
                spans = $progress.children(),
                percent;

            $.each( percentages, function( k, v ) {
                total += v[ 0 ];
                loaded += v[ 0 ] * v[ 1 ];
            } );

            percent = total ? loaded / total : 0;

            spans.eq( 0 ).text( Math.round( percent * 100 ) + '%' );
            spans.eq( 1 ).css( 'width', Math.round( percent * 100 ) + '%' );
            updateStatus();
        }

        function updateStatus() {
            var text = '', stats;

            if ( state === 'ready' ) {
                text = '选中' + fileCount + '个文件，共' +
                    WebUploader.formatSize( fileSize ) + '。';
            } else if ( state === 'confirm' ) {
                stats = uploader.getStats();
                if ( stats.uploadFailNum ) {
                    text = '已成功上传' + stats.successNum+ '个文件至文件夹'+$("#image-folder").val()+'，'+
                        stats.uploadFailNum + '个文件上传失败，<a class="retry" href="#">重新上传</a>失败文件或<a class="ignore" href="#">忽略</a>'
                }

            } else {
                stats = uploader.getStats();
                text = '共' + fileCount + '个（' +
                    WebUploader.formatSize( fileSize )  +
                    '），已上传' + stats.successNum + '个';

                if ( stats.uploadFailNum ) {
                    text += '，失败' + stats.uploadFailNum + '个';
                }
            }

            $info.html( text );
        }

        function setState( val ) {
            var file, stats;

            if ( val === state ) {
                return;
            }

            $upload.removeClass( 'state-' + state );
            $upload.addClass( 'state-' + val );
            state = val;

            switch ( state ) {
                case 'pedding':
                    $placeHolder.removeClass( 'element-invisible' );
                    $queue.parent().removeClass('filled');
                    $queue.hide();
                    $statusBar.addClass( 'element-invisible' );
                    uploader.refresh();
                    break;

                case 'ready':
                    $placeHolder.addClass( 'element-invisible' );
                    $( '#filePicker2' ).removeClass( 'element-invisible');
                    $queue.parent().addClass('filled');
                    $queue.show();
                    $statusBar.removeClass('element-invisible');
                    uploader.refresh();
                    break;

                case 'uploading':
                    $( '#filePicker2' ).addClass( 'element-invisible' );
                    $progress.show();
                    $upload.text( '暂停上传' );
                    break;

                case 'paused':
                    $progress.show();
                    $upload.text( '继续上传' );
                    break;

                case 'confirm':
                    $progress.hide();
                    $upload.text( '开始上传' ).addClass( 'disabled' );

                    stats = uploader.getStats();
                    if ( stats.successNum && !stats.uploadFailNum ) {
                        setState( 'finish' );
                        return;
                    }
                    break;
                case 'finish':
                    stats = uploader.getStats();
                    if ( stats.successNum ) {
                        //alert( '上传成功' );
                        uploader.refresh();
                    } else {
                        // 没有成功的图片，重设
                        state = 'done';
                        location.reload();
                    }
                    break;
            }

            updateStatus();
        }

        /**
         * 上传之前处理参数
         * @param object
         * @param data
         * @param headers
         */
        uploader.onUploadBeforeSend = function( object, data,headers ) {
            data["tags"]=$("#file-tags").val();
            data["folder"]=$("#file-folder").val();
            data["suspName"]= suspicious_list.selected.suspName;
            data["suspId"]=suspicious_list.selected.suspId;
            headers["Authorization"] = sessionStorage.getItem("token");
        };
        /**
         * 上传之后处理返回值
         * @param file
         * @param response
         */
        uploader.onUploadSuccess = function( file, response ) {
            if(window.uplader && response.status===200){
                window.uplader[window.uplader.length] = response.data;
            }else if(response.status===401){
                window.top.location.href="/index.html";
            }
        };
        /**
         * 所有文件上传完成之后
         * @param file
         * @param response
         */
        uploader.onUploadFinished = function() {
            $( '#filePicker2' ).removeClass( 'element-invisible');
            $upload.text( '继续上传' ).removeClass( 'disabled' );
            $("#parserEml").show();
        };

        uploader.onUploadProgress = function( file, percentage ) {
            var $li = $('#'+file.id),
                $percent = $li.find('.progress span');

            $percent.css( 'width', percentage * 100 + '%' );
            percentages[ file.id ][ 1 ] = percentage;
            updateTotalProgress();
        };


        uploader.onFileQueued = function( file ) {
            fileCount++;
            fileSize += file.size;
            var hasFile = false;
            //校验文件的MD5
            browserMD5File(file.source.source, function (err, md5) {
                file["md5"] = md5;
                $.ajax.proxy({
                    url:"/api/admin/file/md5",
                    type:"post",
                    dataType:"json",
                    data:{md5:md5},
                    async:false,
                    success : function (d) {
                        //存在
                        if(d.status===200 && d.data){
                            hasFile = true;
                        }
                    },
                    error:function(){
                        console.error("校验MD5失败");
                    }
                });

                //存在不能导入
                if(hasFile){
                    var rsl = false;
                    if(window.confirm("文件"+file.name+"已导过，是否再次导入？\n重新导入可能会导致数据重复，请谨慎操作！")){
                        if ( fileCount >= 1 ) {
                            $placeHolder.addClass( 'element-invisible' );
                            $statusBar.show();
                        }
                        file["cfdr"]="是";
                        addFile( file );
                        setState( 'ready' );
                        updateTotalProgress();
                    }else {
                        uploader.removeFile(file, true);
                    }
                    // swal({
                    //     title: "该文件已导过，是否再次导入？",
                    //     text: "重新导入可能会导致数据重复，请谨慎操作！",
                    //     type: "warning",
                    //     showCancelButton: true,
                    //     confirmButtonColor: "#DD6B55",
                    //     confirmButtonText: "导入",
                    //     cancelButtonColor: "#DD6B55",
                    //     cancelButtonText: "取消",
                    //     closeOnConfirm: true
                    // }, function (f) {
                    //     if(f){
                    //         if ( fileCount >= 1 ) {
                    //             $placeHolder.addClass( 'element-invisible' );
                    //             $statusBar.show();
                    //         }
                    //         file["cfdr"]="是";
                    //         addFile( file );
                    //         setState( 'ready' );
                    //         updateTotalProgress();
                    //         return;
                    //     }else {
                    //         uploader.removeFile(file, true);
                    //     }
                    // });
                }else{
                    if ( fileCount >= 1 ) {
                        $placeHolder.addClass( 'element-invisible' );
                        $statusBar.show();
                    }

                    addFile( file );
                    setState( 'ready' );
                    updateTotalProgress();
                }
            });

        };

        uploader.onFileDequeued = function( file ) {
            fileCount--;
            fileSize -= file.size;

            if ( !fileCount ) {
                setState( 'pedding' );
            }

            removeFile( file );
            updateTotalProgress();

        };

        uploader.on( 'all', function( type ) {
            var stats;
            switch( type ) {
                case 'uploadFinished':
                    setState( 'confirm' );
                    break;

                case 'startUpload':
                    setState( 'uploading' );
                    break;

                case 'stopUpload':
                    setState( 'paused' );
                    break;

            }
        });

        uploader.onError = function( code ) {
            toastrMsg.info( _showError(code));
        };

        $upload.on('click', function() {
            if ( $(this).hasClass( 'disabled' ) ) {
                return false;
            }
            if(!suspicious_list.selected.suspName || !suspicious_list.selected.suspId){
                toastrMsg.error("请选择人员信息");
                return false;
            }
            // if(!$("#file-tags").val()){
            //     toastrMsg.error("请填写标签");
            //     return false;
            // }
            if(!$("#file-folder").val()){
                toastrMsg.error("请选择文件夹");
                return false;
            }

            if(window.upladerCHecked){
                if(!window.upladerCHecked()){
                    return false;
                }
            }
            if ( state === 'ready' ) {
                uploader.upload();
            } else if ( state === 'paused' ) {
                uploader.upload();
            } else if ( state === 'uploading' ) {
                uploader.stop();
            }
        });

        $info.on( 'click', '.retry', function() {
            uploader.retry();
        } );

        $info.on( 'click', '.ignore', function() {
            //alert( 'todo' );
        } );

        $upload.addClass( 'state-' + state );
        updateTotalProgress();



    })(jQuery);

});
