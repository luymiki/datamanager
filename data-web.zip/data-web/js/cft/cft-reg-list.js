/**
 * Created by hc.zeng on 2018/3/21.
 */
(function (e, t, $) {
    "use strict";

    var reg = (function () {

        var suspid;
        var type;
        var code;

        var _init = function init(_data) {
            var params = utils.getURLParams();
            suspid = params["suspid"];
            type = params["type"];
            code = params["code"];
            _initListTable();
            _event();
        };

        var params = {"indexName":"cftreginfo","conditions":[],"sort":"create_time desc"};

        var _search;//查询的值

        var _initListTable = function(){
            $('#data-table').myTable({
                columns: [{field: 'xh',title: '序号',width:'50px'},
                    {field: 'susp_name',title: '姓名',sortable:true,width:'100px'},
                    {field: 'zh',title: '账号',sortable:true},
                    {field: 'zhzt',title: '账户状态',sortable:true},
                    {field: 'name',title: '注册姓名',sortable:true},
                    {field: 'sfzh',title: '注册身份证号'},
                    {field: 'zcsj',title: '注册时间'},
                    {field: 'dh',title: '手机号'},
                    {field: 'khxx_list',title: '开户行信息',formatter:formatterList},
                    {field: 'yhzh_list',title: '银行账号',formatter:formatterList},
                    {field: 'opt',title: '操作',width:'130px'}
                ],
                ajax : function (request) {
                    var sort = "create_time desc";
                    if(request.data.sortName){
                        sort = request.data.sortName +" "+request.data.sortOrder;
                    }
                    var con = [];
                    if(_search){
                        con=[
                            {
                                "groupId":"1",
                                "groupType":"should",
                                "field": "susp_name",
                                "values": [_search],
                                "searchType": 2,
                                "dataType":1,
                            },
                            {
                                "groupId":"2",
                                "groupType":"should",
                                "field": "qq",
                                "values": [_search],
                                "searchType": 2,
                                "dataType":1,
                            },
                            {
                                "groupId":"3",
                                "groupType":"should",
                                "field": "name",
                                "values": [_search],
                                "searchType": 2,
                                "dataType":1,
                            }
                        ];
                    }
                    if(suspid && type && code){
                        con[con.length]={
                            "field": "susp_id",
                            "values": [suspid],
                            "searchType": 1,
                            "dataType":1,
                        };
                        if("dh" === type){
                            con[con.length]={
                                "field": "dh",
                                "values": [code],
                                "searchType": 1,
                                "dataType":1,
                            };
                        }else if("cft" === type){
                            con[con.length]={
                                "field": "zh",
                                "values": [code],
                                "searchType": 1,
                                "dataType":1,
                            };
                        }else if("yhzh" === type){
                            con[con.length]={
                                "field": "yhzh_list",
                                "values": [code],
                                "searchType": 1,
                                "dataType":1,
                            };
                        }else if("email" === type){
                            con[con.length]={
                                "field": "email",
                                "values": [code],
                                "searchType": 1,
                                "dataType":1,
                            };
                        }

                    }
                    params["sort"]=sort;
                    params["conditions"]=con;
                    $.ajax.proxy({
                        url:"/api/eqa/query",
                        type:"post",
                        dataType:"json",
                        data:{"pageNum":request.data.pageNumber,"pageSize":request.data.pageSize,"paramsStr":JSON.stringify(params)},
                        success : function (msg) {
                            if(msg.status===200){
                                var data = msg.data.data;
                                var xh =  ((request.data.pageNumber-1)*request.data.pageSize)+1;
                                for(var i= 0;i<data.length;i++){
                                    data[i]['xh'] = xh++;
                                    data[i]['opt'] = "<div class='btn btn-primary btn-outline btn-xs detail' data-id='"+data[i]["id"]+"'>查看</div>&nbsp;" +
                                        "<div class='btn btn-info btn-outline btn-xs liushui' data-id='"+data[i]["id"]+"'>流水</div>&nbsp;" +
                                        "<div class='btn btn-danger btn-outline btn-xs delete' data-id='"+data[i]["id"]+"'  data-fileId='"+data[i]["file_id"]+"'>删除</div>&nbsp;"+
                                        "<div class='btn btn-info btn-outline btn-xs analyze' data-id='"+data[i]["id"]+"'>分析</div>";
                                }
                                request.success({
                                    rows : data,
                                    total : msg.data.total
                                });
                            }else {
                                request.success({
                                    rows : [],
                                    total : 0
                                });
                            }
                        },
                        error:function(){
                            toastrMsg.error("系统错误");
                        }
                    });
                }
            });
        };


        var _event = function () {
            $("#addBtn").on('click',function () {
                top.contabs.addMenuItem("/view/cft/cft-reg.html",'导入财付通信息');
            });
            $("#data-table").on('click','.detail',function () {
                top.contabs.addMenuItem("/view/cft/cft-reg-detail.html?id="+$(this).attr("data-id"),'查看信息');
            });
            $("#data-table").on('click','.liushui',function () {
                top.contabs.addMenuItem("/view/cft/liushui/cft-liushui-list.html?id="+$(this).attr("data-id"),'财付通流水列表');
            });
            $("#data-table").on('click','.delete',function () {
                _delete($(this).attr("data-id"),$(this).attr("data-fileId"));
            });
            $("#data-table").on('click','.analyze',function () {
                top.contabs.addMenuItem("/view/cft/analyze/cft-analyze.html?id="+$(this).attr("data-id"),'财付通流水信息分析');
            });
            $("#search-btn").on('click',function () {
                _search = $("#search-input").val();
                if(_search && $.trim(_search) !== ""){
                    $('#data-table').bootstrapTable("refresh");
                }else {
                    _search=null;
                    $('#data-table').bootstrapTable("refresh");
                }
            });
        };

        var _delete = function (id,fileId) {

            swalMsg.msg({
                text:"是否删除财付通信息？",
                type:"warning",
                showCancel:true,
                confirm:function (f) {
                    if(f) {

                        $.ajax.proxy({
                            url: "/api/admin/cft/delete",
                            type: "post",
                            dataType: "json",
                            data:{id: id, fileId:fileId},
                            success: function (d) {
                                console.log(d);
                                if (d.status === 200) {
                                    toastrMsg.success("删除成功");
                                    $('#data-table').bootstrapTable("refresh");
                                } else {
                                    toastrMsg.error("删除失败");
                                }
                            },
                            error: function () {
                                toastrMsg.error("删除失败");
                            }
                        });
                    }
                }
            });


        };

        var formatterList = function (d){
            if(d){
                var s = "";
                for(var i=0 ; i<d.length;i++){
                    s+= d[i]+" ";
                    if(i>10){
                        s+= "...";
                        break;
                    }
                }
                return s;
            }
            return d;
        };

        return {
            init:_init
        };
    })();

    reg.init();


})(document, window, jQuery);
