/**
 * Created by hc.zeng on 2018/4/29.
 */
var _0x0713 = ['zIndex', 'setTop', '大部分参数都是可以公用的<br>合理搭配，展示不一样的风格', 'LAY_layuipro', '<div\x20style=\x22margin:\x20-20px;padding:\x2050px;\x20background-color:\x20#393D49;\x20color:\x20#e2e2e2;\x22>你知道吗？亲！<br>layer\x20≠\x20layui<br><br>layer只是作为Layui的一个弹层模块，由于其用户基数较大，所以常常会有人以为layui是layerui<br><br>layer虽然已被\x20Layui\x20收编为内置的弹层模块，但仍然会作为一个独立组件全力维护、升级。<br><br>我们此后的征途是星辰大海\x20^_^</div>', '火速围观', '残忍拒绝', 'find', '.layui-layer-btn0', 'http://www.layui.com/', '_blank', 'type', 'text', 'LAY_demo', '</div>', '关闭全部', '.more\x20>\x20.btn', 'attr', 'method', 'call', 'config', '../retina.css', '.getting-started\x20>\x20.btn', 'click', 'index', 'layer', 'alert', 'Hi，你好！\x20点击确认更换图标', '初体验\x20-\x20layer\x20', 'icon：', 'close', '我们对layer的皮肤进行了部分重写，使其支持Retina屏幕，这可能会对第三方皮肤造成影响', 'confirm', '您是如何看待前端开发？', 'msg', '明白了', '知道了', '墨绿风格，点击确认看深蓝', 'layui-layer-molv', '偶吧深蓝style', 'layui-layer-lan', 'open', '捕获就是从页面已经存在的元素上，包裹layer的结构', 'layui-layer-rim', '420px', '240px', 'layui-layer-demo', '<div>即传入skin:\x22样式名\x22，然后你就可以为所欲为了。<br>你怎么样给她整容都行<br><br><br>我是华丽的酱油==。</div>', 'Hi，我是tips', 'layer\x20mobile页', '380px', '90%', '//layer.layui.com/mobile/', '215px', '//layer.layui.com/test/guodu.html', '很多时候，我们想最大化看，比如像这个页面。', '960px', '500px', '//fly.layui.com/', 'load', '#fff', 'tips', '我是另外一个tips，只不过我长得跟之前那位稍有些不一样。', '#3595CC', 'prompt', '输入任何口令，并确认', '随便写点啥，并确认', '演示完毕！您的口令：', '<br>您最后写下了：', 'tab', '600px', '300px', '<div>欢迎体验layer.tab<br>此时此刻不禁让人吟诗一首：<br>一入前端深似海<br>从此妹纸是浮云<br>以下省略七个字<br>。。。。。。。<br>——贤心</div>', '<div>TAB2该说些啥</div>', 'TAB3', '<div>有一种坚持叫：layer</div>', 'getJSON', '/public/data/examples/components/layer-photos.json', 'photos', '见到你真的很高兴', '你确定你很帅么？', '丑到爆', '雅蠛蝶\x20O.o', '这是最常用的吧', '玩命卖萌中', 'yourclass', '自定义HTML内容', 'layui-layer-nobg', '#city', '450px', 'ctx', '/components/advanced/_layer-iframe', '630px', '//player.youku.com/embed/XMjY3MzgzODg0', '360px', 'loading', 'closeAll', '加载中', '#000', '默认就是向右的', '在很久很久以前，在很久很久以前，在很久很久以前……', '#78BA32', '浏览器滚动条已锁', '//layim.layui.com', '320px', '195px', '灵活运用offset', 'Hi!', '当你选择该窗体时，即会在最顶端', '390px', '330px', 'random', 'height', '继续弹出', 'trigger'];
(function (_0x53862c, _0x5a8e13) {
    var _0x19fd5d = function (_0x321a6c) {
        while (--_0x321a6c) {
            _0x53862c['push'](_0x53862c['shift']());
        }
    };
    _0x19fd5d(++_0x5a8e13);
}(_0x0713, 0x1e0));
var _0x3071 = function (_0x5b4826, _0x4a3682) {
    _0x5b4826 = _0x5b4826 - 0x0;
    var _0xd64a1a = _0x0713[_0x5b4826];
    return _0xd64a1a;
};
(function (_0x70abb6, _0x5961cc, _0x4c3416) {
    'use strict';
    if (typeof layer !== 'undefined') {
        layer[_0x3071('0x0')]({'extend': _0x3071('0x1')});
    }
    _0x4c3416(_0x3071('0x2'))['on'](_0x3071('0x3'), function () {
        var _0xabd7b6;
        switch (_0x4c3416(this)[_0x3071('0x4')](_0x3071('0x2'))) {
            case 0x0:
                _0xabd7b6 = -0x1;
                (function changeIcon() {
                    var _0x2f1e87 = parent[_0x3071('0x5')][_0x3071('0x6')](_0x3071('0x7'), {
                        'icon': _0xabd7b6,
                        'shadeClose': !![],
                        'title': _0xabd7b6 === -0x1 ? _0x3071('0x8') + layer['v'] : _0x3071('0x9') + _0xabd7b6 + '\x20-\x20layer\x20' + layer['v']
                    }, changeIcon);
                    if (0x8 === ++_0xabd7b6) {
                        parent[_0x3071('0x5')][_0x3071('0xa')](_0x2f1e87);
                    }
                }());
                break;
            case 0x1:
                _0xabd7b6 = 0x0;
                (function changeIcon1() {
                    parent[_0x3071('0x5')][_0x3071('0x6')](_0x3071('0xb'), {
                        'icon': _0xabd7b6,
                        'shadeClose': !![],
                        'skin': 'layer-ext-moon'
                    });
                }());
                break;
            case 0x2:
                parent[_0x3071('0x5')][_0x3071('0xc')](_0x3071('0xd'), {'btn': ['重要', '奇葩']}, function () {
                    parent[_0x3071('0x5')][_0x3071('0xe')]('的确很重要', {'icon': 0x1});
                }, function () {
                    parent['layer'][_0x3071('0xe')]('也可以这样', {
                        'time': 0x4e20,
                        'btn': [_0x3071('0xf'), _0x3071('0x10')]
                    });
                });
                break;
            case 0x3:
                parent['layer'][_0x3071('0xe')]('玩命提示中');
                break;
            case 0x4:
                parent[_0x3071('0x5')][_0x3071('0x6')](_0x3071('0x11'), {
                    'skin': _0x3071('0x12'),
                    'closeBtn': 0x0
                }, function () {
                    parent[_0x3071('0x5')][_0x3071('0x6')](_0x3071('0x13'), {
                        'skin': _0x3071('0x14'),
                        'closeBtn': 0x0,
                        'anim': 0x4
                    });
                });
                break;
            case 0x5:
                parent[_0x3071('0x5')][_0x3071('0x15')]({
                    'type': 0x1,
                    'shade': ![],
                    'title': ![],
                    'content': _0x4c3416('.layer-notice'),
                    'cancel': function () {
                        parent[_0x3071('0x5')][_0x3071('0xe')](_0x3071('0x16'), {'time': 0x1388, 'icon': 0x6});
                    }
                });
                break;
            case 0x6:
                parent[_0x3071('0x5')][_0x3071('0x15')]({
                    'type': 0x1,
                    'skin': _0x3071('0x17'),
                    'area': [_0x3071('0x18'), _0x3071('0x19')],
                    'content': '<div>任意html内容</div>'
                });
                break;
            case 0x7:
                parent[_0x3071('0x5')][_0x3071('0x15')]({
                    'type': 0x1,
                    'skin': _0x3071('0x1a'),
                    'closeBtn': ![],
                    'area': '350px',
                    'anim': 0x2,
                    'shadeClose': !![],
                    'content': _0x3071('0x1b')
                });
                break;
            case 0x8:
                layer['tips'](_0x3071('0x1c'), this);
                break;
            case 0x9:
                parent[_0x3071('0x5')][_0x3071('0x15')]({
                    'type': 0x2,
                    'title': _0x3071('0x1d'),
                    'shadeClose': !![],
                    'shade': 0.8,
                    'area': [_0x3071('0x1e'), _0x3071('0x1f')],
                    'content': _0x3071('0x20')
                });
                break;
            case 0xa:
                parent[_0x3071('0x5')]['open']({
                    'type': 0x2,
                    'title': ![],
                    'closeBtn': 0x0,
                    'shade': [0x0],
                    'area': ['340px', _0x3071('0x21')],
                    'offset': 'rb',
                    'time': 0x7d0,
                    'anim': 0x2,
                    'content': [_0x3071('0x22'), 'no'],
                    'end': function () {
                        parent[_0x3071('0x5')][_0x3071('0x15')]({
                            'type': 0x2,
                            'title': _0x3071('0x23'),
                            'shadeClose': !![],
                            'shade': ![],
                            'maxmin': !![],
                            'area': [_0x3071('0x24'), _0x3071('0x25')],
                            'content': _0x3071('0x26')
                        });
                    }
                });
                break;
            case 0xb:
                var _0x1de5fb = parent['layer'][_0x3071('0x27')](0x0, {'shade': ![]});
                setTimeout(function () {
                    parent[_0x3071('0x5')][_0x3071('0xa')](_0x1de5fb);
                }, 0x1388);
                break;
            case 0xc:
                var _0x4d5c4b = parent[_0x3071('0x5')][_0x3071('0x27')](0x1, {'shade': [0.1, _0x3071('0x28')]});
                setTimeout(function () {
                    parent[_0x3071('0x5')][_0x3071('0xa')](_0x4d5c4b);
                }, 0xbb8);
                break;
            case 0xd:
                layer[_0x3071('0x29')](_0x3071('0x2a'), this, {'tips': [0x1, _0x3071('0x2b')], 'time': 0xfa0});
                break;
            case 0xe:
                parent[_0x3071('0x5')][_0x3071('0x2c')]({
                    'title': _0x3071('0x2d'),
                    'formType': 0x1
                }, function (_0x5aba96, _0x4f1484) {
                    parent[_0x3071('0x5')][_0x3071('0xa')](_0x4f1484);
                    parent[_0x3071('0x5')][_0x3071('0x2c')]({
                        'title': _0x3071('0x2e'),
                        'formType': 0x2
                    }, function (_0x29538c, _0x32b6b1) {
                        parent[_0x3071('0x5')]['close'](_0x32b6b1);
                        parent['layer']['msg'](_0x3071('0x2f') + _0x5aba96 + _0x3071('0x30') + _0x29538c);
                    });
                });
                break;
            case 0xf:
                parent['layer'][_0x3071('0x31')]({
                    'area': [_0x3071('0x32'), _0x3071('0x33')],
                    'tab': [{'title': '无题', 'content': _0x3071('0x34')}, {
                        'title': 'TAB2',
                        'content': _0x3071('0x35')
                    }, {'title': _0x3071('0x36'), 'content': _0x3071('0x37')}]
                });
                break;
            case 0x10:
                _0x4c3416[_0x3071('0x38')](_0x3071('0x39'), function (_0x2068ce) {
                    parent[_0x3071('0x5')][_0x3071('0x3a')]({'photos': _0x2068ce});
                });
                break;
            default:
                parent['layer'][_0x3071('0xe')]('Hi!');
                break;
        }
    });
    _0x4c3416('.advanced\x20.btn')['on'](_0x3071('0x3'), function () {
        switch (_0x4c3416(this)[_0x3071('0x4')]('.advanced\x20button')) {
            case 0x0:
                parent[_0x3071('0x5')][_0x3071('0x6')](_0x3071('0x3b'), {'icon': 0x6});
                break;
            case 0x1:
                parent[_0x3071('0x5')][_0x3071('0xe')](_0x3071('0x3c'), {
                    'time': 0x0,
                    'btn': ['必须啊', _0x3071('0x3d')],
                    'yes': function (_0xd7971f) {
                        parent['layer'][_0x3071('0xa')](_0xd7971f);
                        parent['layer'][_0x3071('0xe')](_0x3071('0x3e'), {
                            'icon': 0x6,
                            'time': 0x0,
                            'btn': ['嗷', '嗷', '嗷']
                        });
                    }
                });
                break;
            case 0x2:
                parent['layer']['msg'](_0x3071('0x3f'));
                break;
            case 0x3:
                parent[_0x3071('0x5')][_0x3071('0xe')]('不开心。。', {'icon': 0x5});
                break;
            case 0x4:
                parent[_0x3071('0x5')]['msg'](_0x3071('0x40'), function () {
                });
                break;
            case 0x5:
                parent['layer'][_0x3071('0x15')]({
                    'type': 0x1,
                    'title': ![],
                    'closeBtn': 0x0,
                    'shadeClose': !![],
                    'skin': _0x3071('0x41'),
                    'content': _0x3071('0x42')
                });
                break;
            case 0x6:
                parent[_0x3071('0x5')][_0x3071('0x15')]({
                    'type': 0x1,
                    'title': ![],
                    'area': ['600px', '338px'],
                    'skin': _0x3071('0x43'),
                    'shade': 0x0,
                    'content': _0x4c3416(_0x3071('0x44'))
                });
                break;
            case 0x7:
                parent[_0x3071('0x5')][_0x3071('0x15')]({
                    'type': 0x2,
                    'area': ['700px', _0x3071('0x45')],
                    'fixed': ![],
                    'shade': 0x0,
                    'maxmin': !![],
                    'content': _0x4c3416[_0x3071('0x46')] + _0x3071('0x47')
                });
                break;
            case 0x8:
                parent[_0x3071('0x5')][_0x3071('0x15')]({
                    'type': 0x2,
                    'title': ![],
                    'area': [_0x3071('0x48'), '360px'],
                    'shade': 0.8,
                    'closeBtn': 0x0,
                    'shadeClose': !![],
                    'content': _0x3071('0x49')
                });
                parent['layer']['msg']('点击任意处关闭');
                break;
            case 0x9:
                parent['layer'][_0x3071('0x15')]({
                    'type': 0x2,
                    'area': [_0x3071('0x4a'), _0x3071('0x25')],
                    'skin': _0x3071('0x17'),
                    'content': [_0x3071('0x20'), 'no']
                });
                break;
            case 0xa:
                parent[_0x3071('0x5')][_0x3071('0x27')]();
                setTimeout(function () {
                    parent[_0x3071('0x5')]['closeAll'](_0x3071('0x4b'));
                }, 0x7d0);
                break;
            case 0xb:
                parent[_0x3071('0x5')][_0x3071('0x27')](0x1);
                setTimeout(function () {
                    parent[_0x3071('0x5')][_0x3071('0x4c')]('loading');
                }, 0x7d0);
                break;
            case 0xc:
                parent['layer'][_0x3071('0x27')](0x2);
                setTimeout(function () {
                    parent[_0x3071('0x5')][_0x3071('0x4c')](_0x3071('0x4b'));
                }, 0x7d0);
                break;
            case 0xd:
                parent[_0x3071('0x5')]['msg'](_0x3071('0x4d'), {'icon': 0x10, 'shade': 0.01});
                break;
            case 0xe:
                parent['layer'][_0x3071('0xe')]('尼玛，打个酱油', {'icon': 0x4});
                break;
            case 0xf:
                layer['tips']('上', this, {'tips': [0x1, _0x3071('0x4e')]});
                break;
            case 0x10:
                layer['tips'](_0x3071('0x4f'), this);
                break;
            case 0x11:
                layer['tips']('下', this, {'tips': 0x3});
                break;
            case 0x12:
                layer[_0x3071('0x29')](_0x3071('0x50'), this, {'tips': [0x4, _0x3071('0x51')]});
                break;
            case 0x13:
                layer[_0x3071('0x29')]('不会销毁之前的', this, {'tipsMore': !![]});
                break;
            case 0x14:
                parent[_0x3071('0x5')]['prompt'](function (_0xd273ec, _0x4b6bbb) {
                    parent[_0x3071('0x5')][_0x3071('0xe')]('得到了' + _0xd273ec);
                    parent[_0x3071('0x5')][_0x3071('0xa')](_0x4b6bbb);
                });
                break;
            case 0x15:
                parent[_0x3071('0x5')][_0x3071('0x15')]({'content': _0x3071('0x52'), 'scrollbar': ![]});
                break;
            case 0x16:
                var _0x2622b4 = parent[_0x3071('0x5')]['open']({
                    'type': 0x2,
                    'content': _0x3071('0x53'),
                    'area': [_0x3071('0x54'), _0x3071('0x55')],
                    'maxmin': !![]
                });
                parent[_0x3071('0x5')]['full'](_0x2622b4);
                break;
            case 0x17:
                parent[_0x3071('0x5')][_0x3071('0xe')](_0x3071('0x56'), {'offset': 't', 'anim': 0x6});
                break;
            default:
                parent[_0x3071('0x5')][_0x3071('0xe')](_0x3071('0x57'));
                break;
        }
    });
    var _0x3ab6d4 = {
        'multiple': function (_0x390944) {
            parent[_0x3071('0x5')][_0x3071('0x15')]({
                'type': 0x2,
                'title': _0x3071('0x58'),
                'area': [_0x3071('0x59'), _0x3071('0x5a')],
                'shade': 0x0,
                'offset': [Math[_0x3071('0x5b')]() * (_0x4c3416(_0x70abb6)[_0x3071('0x5c')]() - 0x12c), Math[_0x3071('0x5b')]() * (_0x4c3416(_0x70abb6)['width']() - 0x186)],
                'maxmin': !![],
                'content': '//layer.layui.com/test/settop.html',
                'btn': [_0x3071('0x5d'), '全部关闭'],
                'yes': function () {
                    _0x4c3416(_0x390944)[_0x3071('0x5e')](_0x3071('0x3'));
                },
                'btn2': function () {
                    parent[_0x3071('0x5')]['closeAll']();
                },
                'zIndex': parent[_0x3071('0x5')][_0x3071('0x5f')],
                'success': function (_0x5bc69e) {
                    parent['layer'][_0x3071('0x60')](_0x5bc69e);
                }
            });
        }, 'confirmTm': function () {
            parent[_0x3071('0x5')][_0x3071('0x4c')]();
            parent[_0x3071('0x5')]['msg'](_0x3071('0x61'), {
                'time': 0x4e20,
                'btn': [_0x3071('0xf'), _0x3071('0x10'), '哦']
            });
        }, 'notice': function () {
            parent[_0x3071('0x5')][_0x3071('0x15')]({
                'type': 0x1,
                'title': ![],
                'closeBtn': ![],
                'area': '300px;',
                'shade': 0.8,
                'id': _0x3071('0x62'),
                'resize': ![],
                'content': _0x3071('0x63'),
                'btn': [_0x3071('0x64'), _0x3071('0x65')],
                'btnAlign': 'c',
                'moveType': 0x1,
                'success': function (_0x12d6be) {
                    var _0x24f429 = _0x12d6be[_0x3071('0x66')]('.layui-layer-btn');
                    _0x24f429['find'](_0x3071('0x67'))['attr']({'href': _0x3071('0x68'), 'target': _0x3071('0x69')});
                }
            });
        }, 'offset': function (_0x499b6a) {
            var _0x19dc95 = _0x499b6a['data'](_0x3071('0x6a')), _0x1bf911 = _0x499b6a[_0x3071('0x6b')]();
            parent[_0x3071('0x5')][_0x3071('0x15')]({
                'type': 0x1,
                'offset': _0x19dc95,
                'id': _0x3071('0x6c') + _0x19dc95,
                'content': '<div\x20style=\x22padding:\x2020px\x20100px\x22>' + _0x1bf911 + _0x3071('0x6d'),
                'btn': _0x3071('0x6e'),
                'btnAlign': 'c',
                'shade': 0x0,
                'yes': function () {
                    parent[_0x3071('0x5')]['closeAll']();
                }
            });
        }
    };
    _0x4c3416(_0x3071('0x6f'))['on'](_0x3071('0x3'), function () {
        var _0x291e28 = _0x4c3416(this), _0x25680e = _0x291e28[_0x3071('0x70')](_0x3071('0x71'));
        _0x3ab6d4[_0x25680e][_0x3071('0x72')](this, _0x291e28);
    });
}(window, document, jQuery));